# Hello, world

HW 3, Digiprof on Android

Hieu is still not gay guys!!

Not cool man :( 

Latest version of DigiProf - UsersFragment is buggy. HomeFragment + ProfileFragment work as expected. 